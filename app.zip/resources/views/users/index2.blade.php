@extends('layouts.app')

@section('content')
<div class="container">


   @include('main.servergetDataTable')
 
</div>


<script type="text/javascript">
    

</script>
@endsection
