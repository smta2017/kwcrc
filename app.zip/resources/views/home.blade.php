@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">القائمة</div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                     <a href="/crudnews" class="btn btn-primary btn-block mainmenue">الاخبار</a>
                     <a href="/crudsiminar" class="btn btn-primary btn-block mainmenue">الندوات</a>
                     <a href="" class="btn btn-primary btn-block mainmenue">الفاعليا</a>
                     <a href="crudportfoliocat" class="btn btn-primary btn-block mainmenue">تصنيف البوم الصور</a>
                     <a href="crudportfolio" class="btn btn-primary btn-block mainmenue">البوم الصور</a>
                     <a href="" class="btn btn-primary btn-block mainmenue">الاعضاء</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
