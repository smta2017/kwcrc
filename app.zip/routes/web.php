<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\portfoliocat;
use App\Portfolio;
Route::get('/', function () {
	$potcats = portfoliocat::all();
	$portfolios = Portfolio::all();
	return view('welcome',compact('potcats','portfolios'));
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

//-----------------------------news-------------------------------
Route::get('/news', 'NewsController@index');
Route::get('/crudnews', 'NewsController@crudnews');


//-----------------------------siminar-------------------------------
Route::get('/siminars', 'SiminarController@index');
Route::get('/crudsiminar', 'SiminarController@crudsiminar');


//-----------------------------portfolio-------------------------------
Route::get('/crudportfoliocat', 'PortfolioController@crudportfoliocat');
Route::get('/crudportfolio', 'PortfolioController@crudportfolio');


Route::get('/test', function () {
	return view('test');
});



//=============================================================================================



//----------------------------------------------------------------------------------
//-----------------------------Main Routs-------------------------------------------
Route::get('/gettbldata', 'MainController@gettbldata')->name('gettbldata'); 	  //
Route::get('/paginatresult/{page}',     'MainController@paginatreturn');		  //
Route::get('/getsearchresult',     'MainController@getsearchresult');   		  //
Route::post('/savetbldata',     'MainController@saveadd');						  //
Route::post('/deleterow',     'MainController@deleterow');						  //
//----------------------------End Main Routs----------------------------------------
//----------------------------------------------------------------------------------



//=============================================================================================
