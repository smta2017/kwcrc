

<?php $__currentLoopData = $Datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $Data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $thDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $options): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $cloNamev=$options->tbName . $options->colName; ?>

<?php if(trim($options->editModeType)!=''): ?>
<?php if(trim($options->editModeType)=='text'): ?>
<div class="control-group">
	<label class="control-label"><?php echo e($options->titleEN); ?> </label>
	<div class="controls">
		<input type="text" value="<?php echo e($Data->$cloNamev); ?>" class="span3" <?php if($options->required): ?> required <?php endif; ?>  name="<?php echo e(trim($cloNamev)); ?>"/>
	</div>
</div>

<?php elseif(trim($options->editModeType)=='datepicker'): ?>

<div class="control-group">
	<label class="control-label"><?php echo e($options->titleEN); ?> </label>
	<div class="controls">
		<input type="text" value="<?php echo e($Data->$cloNamev); ?>" class="span3 datepickerCTRL" <?php if($options->required): ?> required <?php endif; ?>  name="<?php echo e(trim($cloNamev)); ?>"/>
	</div>
</div>


<?php endif; ?>
<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
