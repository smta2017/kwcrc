  <?php if($thDatas->count()>0): ?>


  



  <h1 style="margin-top: -10px "><?php echo e($thDatas[0]->Systemtable->titleEN); ?></h1> 
  <hr>





 

  <div  class="modal fade editmodal"  >
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button data-dismiss="modal" class="close" type="button">×</button>
          <h3>تعديل - (<?php echo e($thDatas[0]->Systemtable->titleEN); ?>)</h3>
        </div>
        <form method="" action="" class="form-horizontal">
          <div class="modal-body">
         <?php echo e(csrf_field()); ?>



        <input type="hidden" value="<?php echo e($thDatas[0]->Systemtable->id); ?>" name="table_id">
        <input type="hidden" value="1" name="isSearch">

         <div class="vovo" style="padding: 20px">

         </div>

         <div class="modal-footer">

          <button type="submit" style="float: right;" class="btn btn-primary"> <i class="icon-save"></i> Save</button>

        </div>
      </div>
      </form>
    </div>
  </div>
</div>






<div  class="modal fade addmodal"  >
    <div class="modal-dialog" role="document">
                        <div class="modal-content">
    <div class="modal-header">
      <button data-dismiss="modal" class="close" type="button">×</button>
      <h3>الإضافة - (<?php echo e($thDatas[0]->Systemtable->titleEN); ?>)</h3>
    </div>
     <form   action="savetbldata"  method="post" class="form-horizontal form-bordered form-label-stripped"   enctype="multipart/form-data"  tableid="<?php echo e($thDatas[0]->Systemtable->id); ?>">
      <div class="modal-body">
    <?php echo e(csrf_field()); ?>


        <input type="hidden" value="<?php echo e($thDatas[0]->Systemtable->id); ?>" name="table_id">
        
        <?php $__currentLoopData = $thDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $options): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $cloNamev=$options->colName; ?>


        <?php if(trim($options->addModeType)!=''): ?>
        <?php if(trim($options->addModeType)=='text'): ?>

        <div class="control-group">
          <label class="control-label"><?php echo e($options->titleEN); ?> </label>
          <div class="controls">
            <input type="text" class="span3" <?php if($options->required): ?> required <?php endif; ?>  name="<?php echo e(trim($cloNamev)); ?>"/>
          </div>
        </div>

        <?php elseif(trim($options->addModeType)=='datepicker'): ?>
          <div class="control-group">
          <label class="control-label"><?php echo e($options->titleEN); ?> </label>
          <div class="controls">
          <input type="text" class="span3 datepickerCTRL" <?php if($options->required): ?> required <?php endif; ?>  name="<?php echo e(trim($cloNamev)); ?>"/>   
          </div>
        </div>


        <?php elseif(trim($options->addModeType)=='dropdown'): ?>
        <div class="control-group">
          <label class="control-label"><?php echo e($options->titleEN); ?> </label>
          <div class="controls">
            <?php if($options->tableDataSource): ?>


            <?php echo e(Form::select(explode('@', $options->tableDataSource)[0] . '_id',  
            array(''=>'اختر ...') + DB::table(explode('@', $options->tableDataSource)[0].'s')->pluck(explode('@', $options->tableDataSource)[1], 'id')->toArray(), 'null', array($options->required) +array('class' => 'span3 required search_' . $options->CustomClass,'id' => explode('@', $options->tableDataSource)[0] . '_id', $options->required))); ?>

            <?php endif; ?>

          </div>
        </div>
        <?php elseif(trim($options->addModeType)=='checkbox'): ?>
        
        <div class="control-group">
          <label class="control-label"><?php echo e($options->titleEN); ?> </label>
          <div class="controls">
            <input type="checkbox"   name="<?php echo e(trim($cloNamev)); ?>"/>

          </div>
        </div>
        
          <?php elseif(trim($options->addModeType)=='file'): ?>

          <div class="control-group">
            <label class="control-label"><?php echo e($options->titleEN); ?> </label>
            <div class="controls">
              <input type="file"   name="<?php echo e(trim($cloNamev)); ?>"/>

            </div>
          </div>
        <?php endif; ?>
        <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        

 
      
    </div>
    <div class="modal-footer">
                       
      <button type="submit" style="float: right;" class="btn btn-success"> <i class="icon-save"></i> Save</button>
     
     </div>
  </form>
</div></div>

  </div>











  <div  class="modal fade searchmodal"  >
     <div class="modal-dialog" role="document">
                        <div class="modal-content">
  	<div class="modal-header">
  		<button data-dismiss="modal" class="close" type="button">×</button>
  		<h3>البحث - (<?php echo e($thDatas[0]->Systemtable->titleEN); ?>)</h3>
  	</div>
    <form action="gettbldata"  method="get" class="form-horizontal">
  	 <div class="modal-body">
  		

  			<input type="hidden" value="<?php echo e($thDatas[0]->Systemtable->id); ?>" name="table_id">
  			<input type="hidden" value="1" name="isSearch">
  			<?php $__currentLoopData = $thDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $options): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  			<?php $cloNamev=$options->colName; ?>


  			<?php if(trim($options->searchModeType)!=''): ?>
  			<?php if(trim($options->searchModeType)=='text'): ?>

  			<div class="control-group">
  				<label class="control-label"><?php echo e($options->titleEN); ?> </label>
  				<div class="controls">
  					<input type="text" class="span3"  name="<?php echo e(trim($cloNamev)); ?>"/>
  				</div>
  			</div>


        <?php elseif(trim($options->searchModeType)=='datepicker'): ?>
          <div class="control-group">
          <label class="control-label"><?php echo e($options->titleEN); ?> </label>
          <div class="controls">
              <input type="text" class="span3 datepickerCTRL"  name="<?php echo e(trim($cloNamev)); ?>"/>
          </div>
        </div>
      

  			<?php elseif(trim($options->searchModeType)=='dropdown'): ?>
  			<div class="control-group">
  				<label class="control-label"><?php echo e($options->titleEN); ?> </label>
  				<div class="controls">
  					<?php if($options->tableDataSource): ?>


  					<?php echo e(Form::select(explode('@', $options->tableDataSource)[0] . '_id',  
  					array(''=>'اختر ...') + DB::table(explode('@', $options->tableDataSource)[0].'s')->pluck(explode('@', $options->tableDataSource)[1], 'id')->toArray(), 'null', array('class' => 'span3 required search_' . $options->CustomClass,'id' => explode('@', $options->tableDataSource)[0] . '_id'))); ?>

  					<?php endif; ?>

  				</div>
  			</div>
  			<?php elseif(trim($options->searchModeType)=='checkbox'): ?>
  			
  			<div class="control-group">
  				<label class="control-label"><?php echo e($options->titleEN); ?> </label>
  				<div class="controls">
  					<input type="checkbox"   name="<?php echo e(trim($cloNamev)); ?>"/>

  				</div>
  			</div>
  			<?php endif; ?>
  			<?php endif; ?>

  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  			

  		
  		
  	</div>
     <div class="modal-footer">
          <button type="submit" style="float: right;" class="btn btn-info"  > <i class="icon-search"></i> Search </button>
       </div>
  </form>
   </div> </div>
  </div>

  
 













 
  <div class="btn-group btn-group-sm" role="group" style="padding-bottom:  10px;float: right;">
      <button type="button" class="btn btn-info searchlink"> <i class="fa fa-search"></i> بحث</button>
      <button type="button" class="btn btn-success addlink"> <i class="fa fa-plus"></i> إضافة</button>
  </div> 
  
  <div id="loadingDiv" style=" overflow: hidden;" >
    <img src="img/loadnew.gif" width="150" style="  margin: -30px -55px 0px 0px;"> 
  </div>
  
 <?php echo $alertnote;?>
  <div class="widget-content nopadding">
  	<table id="users" editable="1" deletable="1" class="<?php echo e($thDatas[0]->Systemtable->cssClass); ?>">
  		<thead>
  			<tr>
  				<?php $__currentLoopData = $thDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $thData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(!$thData->include): ?>
  				<th style="text-align: right;"><?php echo e($thData->titleEN); ?></th>
           <?php endif; ?>
  				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php if($thDataextas->count()>0 || $thDataextas2->count()>0): ?>
          <th <?php if(!$tdWidth==''): ?> style="text-align: right;width: <?php echo e($tdWidth); ?>;" <?php endif; ?> >تحكم</th>
          <?php endif; ?>
        </tr>
      </thead>
      <tbody>
       <?php if($Datas->count()!=0): ?>
     

       <?php $__currentLoopData = $Datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $Data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr id="<?php echo e(trim($Data->id)); ?>">
        <?php $__currentLoopData = $thDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $options): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $cloNamev=$options->tbName . $options->colName; ?>
     <?php if(!$options->include): ?>  
      <td id="<?php echo e(trim($options->colName)); ?>">
                          <?php if(trim($options->isLink)!=''): ?>
                             <?php if($options->tableDataSource): ?>
                                    <?php $cloNamev=explode('@', $options->tableDataSource)[1];
                                    $cloNamevid = explode('@', $options->tableDataSource)[0].'s_id' ?>
                                    <span style="font-size:10px"><?php echo e(trim($Data->$cloNamevid)); ?>   -</span>  
                                    <a href="<?php echo e(trim($options->isLink)); ?>" id="<?php echo e(trim($Data->$cloNamevid)); ?>" class="<?php echo e(trim($options->CustomClass)); ?>"><?php echo e(trim($Data->$cloNamev)); ?></a>
                                <?php else: ?>
                                     <a href="<?php echo e(trim($options->isLink)); ?>" id="<?php echo e(trim($Data->id)); ?>" class="<?php echo e(trim($options->CustomClass)); ?>"><?php echo e(trim($Data->$cloNamev)); ?></a>
                                <?php endif; ?>
                          <?php elseif(trim($options->displayModeType)=='checkbox'): ?>
                              <input class="<?php echo e(trim($options->CustomClass)); ?>"  type="checkbox"  <?php if(trim($Data->$cloNamev)==1): ?> checked <?php endif; ?>  name"<?php echo e($options->colName); ?>">
                          <?php elseif(trim($options->displayModeType)=='dropdown'): ?>
                              <?php echo e($options->tableDataSource); ?>

                              <select>
                                <option>0</option>
                              </select>
                          <?php elseif(trim($options->displayModeType)=='textbox'): ?>
                              <input  class="<?php echo e(trim($options->CustomClass)); ?>" type="text" name="<?php echo e(trim($Data->$cloNamev)); ?>">
                          <?php else: ?>
                                <?php if($options->tableDataSource): ?>
                                    <?php $cloNamev=explode('@', $options->tableDataSource)[1];
                                    $cloNamevid = explode('@', $options->tableDataSource)[0].'s_id' ?>
                                    <span style="font-size:1px"><?php echo e(trim($Data->$cloNamevid)); ?>   -</span>  <?php echo e(trim($Data->$cloNamev)); ?>

                                <?php else: ?>
                                    <?php echo e(trim($Data->$cloNamev)); ?>

                      
                                <?php endif; ?>
                          <?php endif; ?>
                   <?php $__currentLoopData = $includedColum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $cloNamev3=$value->tbName . $value->include;  $colNamevd=$value->tbName . $value->colName;?>
                    <?php if( $options->id==$cloNamev3): ?>
                <br>
                          <?php if(trim($value->isLink)!=''): ?>
                            <?php if($value->tableDataSource): ?>
                                <?php $colNamevd=explode('@', $value->tableDataSource)[1];
                                $cloNamevid = explode('@', $value->tableDataSource)[0].'s_id' ?>
                                <span style="font-size:1px"><?php echo e(trim($Data->$cloNamevid)); ?>   -</span>   
                                <a href="<?php echo e(trim($value->isLink)); ?>" id="<?php echo e(trim($Data->$cloNamevid)); ?>" class="<?php echo e(trim($value->CustomClass)); ?>"> <?php echo e(trim($Data->$colNamevd)); ?></a>
                            <?php else: ?>
                                <a href="<?php echo e(trim($value->isLink)); ?>" id="<?php echo e(trim($Data->id)); ?>" class="<?php echo e(trim($value->CustomClass)); ?>">  <?php echo e(trim($Data->$colNamevd)); ?></a>
                            <?php endif; ?>
                          <?php elseif(trim($value->displayModeType)=='checkbox'): ?>
                              <input  class="<?php echo e(trim($value->CustomClass)); ?>" class="<?php echo e(trim($options->CustomClass)); ?>" type="checkbox"  <?php if(trim($Data->$colNamevd)==1): ?> checked <?php endif; ?>  name"<?php echo e($value->colName); ?>">
                          <?php elseif(trim($value->displayModeType)=='dropdown'): ?>
                              <?php echo e($value->tableDataSource); ?>

                              <select>
                                <option>0</option>
                              </select>
                          <?php elseif(trim($value->displayModeType)=='textbox'): ?>
                              <input  class="<?php echo e(trim($value->CustomClass)); ?>" type="text" name="<?php echo e(trim($Data->$colNamevd)); ?>">
                          <?php else: ?>
                                <?php if($value->tableDataSource): ?>
                                    <?php $colNamevd=explode('@', $value->tableDataSource)[1];
                                    $cloNamevid = explode('@', $value->tableDataSource)[0].'s_id' ?>
                                    <span style="font-size:1px"><?php echo e(trim($Data->$cloNamevid)); ?>   -</span>   
                                    <span  class="<?php echo e(trim($value->CustomClass)); ?>"> <?php echo e(trim($Data->$colNamevd)); ?></span>
                                <?php else: ?>
                                    <span  class="<?php echo e(trim($value->CustomClass)); ?>">  <?php echo e(trim($Data->$colNamevd)); ?></span>
                                <?php endif; ?>
                          <?php endif; ?>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td> 
     <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($thDataextas->count()>0 || $thDataextas2->count()>0): ?>
        <td >
         <?php if($thDataextas2->count()>0): ?>
         <?php $__currentLoopData = $thDataextas2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $Ctrloptions2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <a href="#" id="<?php echo e($Data->id); ?>" class="<?php echo e($Ctrloptions2->btnclass); ?>" ><?php echo e($Ctrloptions2->titleEN); ?></a>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>
         <?php if($thDataextas->count()>0): ?>
         <div class="btn-group">
          <button data-toggle="dropdown" class="btn btn-xs  dropdown-toggle" style="margin-left: 15px" >تحكم <span class="caret"></span></button>
          <ul class="dropdown-menu">
           <?php $__currentLoopData = $thDataextas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $Ctrloptions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <li><a href="#" id="<?php echo e($Data->id); ?>" class="<?php echo e($Ctrloptions->btnclass); ?>" ><?php echo e($Ctrloptions->titleEN); ?></a></li>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
       </div>
       <?php endif; ?>
     </td>
     <?php endif; ?>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php else: ?>
   <tr><td><b> لا توجد بيانات..!</b></td></tr>
   <?php endif; ?>
 </tbody>
</table>
</div>
<div class="pagination alternate" datatableid="<?php echo e($thDatas[0]->Systemtable->id); ?>"  style="margin: 0px 0;">
 <?php echo e($Datas->appends(['insearch' => $insearch])->links()); ?>

</div>
<?php endif; ?>