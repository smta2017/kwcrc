<?php $__env->startSection('content'); ?>



<main id="main">


    <!--==========================
      About Us Section
      ============================-->
      <section id="about">
      	<div class="container">
      	 
      		<header class="section-header" style="padding: 150px 0 0 0">
      			<h3> اخبارنا</h3>
      			<p>يمكنك التعرف على لجنتنا والاطلاع على اهدافنا لمشاركتنا الرأي والرؤية</p>
      		</header>

      		<div class="row about-cols" style="min-height: 700px;text-align: right;">

      			<table class="table table-sm table-dark" style="border-radius: 20px" >
      				 
      				<tbody>
      					<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      					<tr>
      						 
      						<td style="width: 230px"><a href="#"><img src="img/logo2.png" alt="newimg" width="200" class="img-thumbnail"></a></td>
      						<td>
      							<?php echo e($new->title); ?>    <br>
      						<span style="font-size: 12px !important">	<?php echo e($new->detail); ?>  </span> <br>
      						
      						<span style="font-size: 10px !important"><?php echo e($new->created_at); ?> </span> </td>
      					</tr>
      					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      				</tbody>
      			</table>


      		</div>

      	</div>
      </section><!-- #about -->


      <?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutsite.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>