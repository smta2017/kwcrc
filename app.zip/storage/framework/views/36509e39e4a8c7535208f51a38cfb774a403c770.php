<?php $__env->startSection('customeCSS'); ?>

<style>
	.nav-menu a{
		color: green;
	}
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


 
    <!--==========================
      About Us Section
      ============================-->
      <section id="services"  >
      	<div class="container">

      		<header class="section-header" style="padding: 150px 0 0 0">
      			<h3> الندوات</h3>
      			<p>ارشيف ندواتنا</p>
      		</header>

      		<div class="row about-cols" style="min-height: 700px;text-align: right;">

      			<table class="table table-sm " style="border-radius: 3px;background: #34495E;" >

      				<tbody>
      					<?php $__currentLoopData = $siminars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siminar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      					<tr>

      						<td style="padding: 20px ;width: 230px"><a href="#"><img src="http://kwcrc.com/storage/app/public/news_attach/news_<?php echo e($siminar->id); ?>" alt="newimg" width="200" class="img-thumbnail"></a></td>



      						<td style="color: #ffffff">
      							<div style="color:#dd5;padding: 10px"> 	<?php echo e($siminar->title); ?> </div>    
      							<div style=" font-size: 12px !important; padding:  10px 10px 10px 40px ">	<?php echo e($siminar->detail); ?>  </div>  

      							<div style="font-size: 10px !important"><?php echo e($siminar->created_at); ?> </div> 
      						</td>
      					</tr>
      					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      				</tbody>
      			</table>


      		</div>

      	</div> 
      </section><!-- #about -->


      <?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutsite.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>