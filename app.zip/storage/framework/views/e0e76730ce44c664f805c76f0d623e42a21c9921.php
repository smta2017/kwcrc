<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		 
		<div class="col">
			<div class="dodo" datatableid="11" >

			</div>
		</div>
	</div>
</div>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('footersection'); ?>
 <script src="mainjs/mainjs.js" type="text/javascript" ></script>
 
<script>
  $(document).ready(function(e){
   $('div').each(function(){
       if ($(this).attr('datatableid')) {
           fechdatatableindiv($(this),1);
       }
   });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>