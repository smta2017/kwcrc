<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Siminar;
class SiminarController extends Controller
{ 

	public function __construct()
    {
        $this->middleware('auth',['except' => ['index']]);
    }


	public function crudsiminar()
	{
		return view('siminar.crudsiminar');  
	}

	public function index()
	{

		$siminars =Siminar::orderBy('id','desc')->get();

		return view('siminar.index',compact('siminars'));  
	}

}
