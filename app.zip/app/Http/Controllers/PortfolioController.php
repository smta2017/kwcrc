<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PortfolioController extends Controller
{
    	public function __construct()
    {
        $this->middleware('auth',['except' => ['index']]);
    }


	public function crudportfoliocat()
	{
		return view('portfolio.portfoliocatscrud');  
	}

	public function crudportfolio()
	{
		return view('portfolio.portfolioscrud');  
	}
}
