<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Siminar extends Model
{
    //
}
